package classeExecutavel;

import model.circulo;
import model.retangulo;

public class classeExecutavel {

	public static void main(String[] args) {
			circulo circulo = new circulo();
		
		circulo.setRaio(5);
		
		System.out.println("Area do Disco: " +circulo.calcularAreaDisco());
		System.out.println("Circunferência: " +circulo.calcularCircunferencia());
		System.out.println("Superfície: " +circulo.calcularSuperficie());
		System.out.println("Volume: " +circulo.calcularVolume());

	}

}
