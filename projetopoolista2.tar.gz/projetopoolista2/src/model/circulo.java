package model;

public class circulo {
	float p1 = 3.141592f;
	private float raio;
	private float areaDisco;
	private float circunferencia;
	private float superficie;
	private float volume;
	
	
	public float getRaio() {
		return raio;
	}
	public void setRaio(float raio) {
		this.raio = raio;
	}
	public float getAreaDisco() {
		return areaDisco;
	}
	public float getCircunferencia() {
		return circunferencia;
	}
	public float getSuperficie() {
		return superficie;
	}
	public float getVolume() {
		return volume;
	}
	
	public float calcularAreaDisco(){
		this.areaDisco = 3.141592f * this.raio * this.raio;
		return this.areaDisco;
	}
	public float calcularCircunferencia() {
		this.circunferencia = 2*3.141592f * raio;
		return this.circunferencia;
	}
	public float calcularSuperficie() {
		this.superficie = 4*3.141592f*raio*raio;
		return this.superficie;
	}
	public float calcularVolume() {
		this.volume = 3.141592f*raio*raio;
		return this.volume;
	}
}
