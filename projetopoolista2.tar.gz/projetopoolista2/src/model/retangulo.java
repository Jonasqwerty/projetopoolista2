package model;

public class retangulo {
	private float area;
	private float perimetro;
	
	public float getArea() {
		return area;
	}
	public float getPerimetro() {
		return perimetro;
	}
	public float calcularArea(float b, float h) {
		this.area = b*h;
		return area;
	}
	public float calcularPerimetro(float b, float h) {
		return this.perimetro = 2*b + 2*h;
	}

}
